var path = require("path");
var express = require("express");
var logger = require("morgan");
var bodyParser = require("body-parser");
var cheerio = require("cheerio");
var http = require("http");
var request = require("request");
var fs = require("fs");

var url = 'http://opendata.epa.gov.tw/webapi/Data/REWIQA/?$orderby=SiteName&$skip=0&$top=1000&format=json';
http.get(url, function(response){
    var data = '';
    response.on('data', function(chunk){
        data += chunk;
    });
    response.on('end', function(){
        data = JSON.parse(data);
fs.writeFile('save.json', JSON.stringify( data ), function(err, result) {
     if(err) console.log('error', err);
   });
    });
});

var app = express();

app.get("/api",function(request,response){
	var file = path.join(__dirname, 'save.json');
	fs.readFile(file, 'utf-8', function(err,data){
		if (err)
			response.send('文件讀取失敗');
		else
		    response.send(data);
	});
});

app.set("views", path.resolve(__dirname, "views"));
app.set("view engine", "ejs");
var entries =[];
app.locals.entries = entries;
app.use(logger("dev"));
app.use(bodyParser.urlencoded({ extended: false }));

app.get("/",function(request,response){
	response.render("test");
});
app.post("/", function(request , response ){
  console.log(request.body)
  var json = require('jsonfile');
  json.readFile('save.json', function(err, results) {
  if (err) { console.log("讀取成功!");
    throw err;  
  }
  else {
      for (i=0;i<80;i++){
        if(results[i].SiteName == request.body.SiteName){
          var SiteName = results[i].SiteName;
          var County = results[i].County;
          var Aqi = results[i].AQI;
          var Status = results[i].Status;
          var O3 = results[i].O3;
          var PM10 = results[i].PM10;
          var Co = results[i].CO;
          var SO2 = results[i].SO2;
          var NO2 = results[i].NO2;
          var PublishTime = results[i].PublishTime;

          response.render("index2",{
            S : request.body.SiteName,
            C : request.body.County,
            A : Aqi,
            St : Status,
            O : O3,
            P : PM10,
            Co : Co,
            So : SO2,
            No : NO2,
            Pu : PublishTime
          });
        }
      }
    }
  });
});

app.use(function(request, response) {
  response.status(404).render("404");
});

http.createServer(app).listen(3000, function() {
  console.log("Guestbook app started on port 3000.");
});