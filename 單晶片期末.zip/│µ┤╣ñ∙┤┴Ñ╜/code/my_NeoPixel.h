void clearLEDs(void);
void cyclone(unsigned long color, byte wait); 
void cascade(unsigned long color, byte direction, byte wait);
void rainbow(byte startPosition);
uint32_t rainbowOrder(byte position);
// 龍捲風函數=============================================================
void cyclone(unsigned long color, byte wait) {
  // weight 為淡化外部眼顏色的亮
  const byte weight = 4;  
  // 分離24位元格式為8位元RGB格式
  byte red = (color & 0xFF0000) >> 16;
  byte green = (color & 0x00FF00) >> 8;
  byte blue = (color & 0x0000FF);
  // 由最近的LED往內移
  for (int i=0; i<=LED_CNT-1; i++)  {
    clearLEDs();  // 關閉所有LED
    leds.setPixelColor(i, red, green, blue);  // 設定亮的中間眼Set the bright middle eye
    // 使兩個眼往兩側逐漸變暗
    for (int j=1; j<3; j++)  {
      if (i-j >= 0)
        leds.setPixelColor(i-j, red/(weight*j), green/(weight*j), blue/(weight*j));
      if (i-j <= LED_CNT)
        leds.setPixelColor(i+j, red/(weight*j), green/(weight*j), blue/(weight*j));
    }
    leds.show();  // Turn the LEDs on
    delay(wait);  // Delay for visibility
  }
  // 反向操作
  for (int i=LED_CNT-2; i>=1; i--) {
    clearLEDs();  // 關閉所有LED
    leds.setPixelColor(i, red, green, blue);
    for (int j=1; j<3; j++)  {
      if (i-j >= 0)
        leds.setPixelColor(i-j, red/(weight*j), green/(weight*j), blue/(weight*j));
      if (i-j <= LED_CNT)
        leds.setPixelColor(i+j, red/(weight*j), green/(weight*j), blue/(weight*j));
    }
    leds.show();  // 開啟所有LED
    delay(wait);  // 持續顯示wait時間
  }
}
// 瀑布函數===============================================================
void cascade(unsigned long color, byte direction, byte wait)
{
  if (direction == TOP_DOWN) {
  // 由上而下
    for (int i=0; i<LED_CNT; i++) {
      clearLEDs();  			// 關閉所有LED
      leds.setPixelColor(i, color);	// 設定此LED的顏色
      leds.show();  			// 開啟所有LED
      delay(wait);  			// 持續顯示wait時間
    }
  }
  else  {
  // 由下而上
    for (int i=LED_CNT-1; i>=0; i--) {
      clearLEDs();  			// 關閉所有LED
      leds.setPixelColor(i, color);	// 設定此LED的顏色
      leds.show();  			// 開啟所有LED
      delay(wait);  			// 持續顯示wait時間
    }
  }
}
// 關閉所有LED函數==========================================================
// 設定顏色為黑色，再呼叫show()函數，即可關閉LED
void clearLEDs()
{
  for (int i=0; i<LED_CNT; i++) {
    leds.setPixelColor(i, 0);
  }
}
// 彩虹函數================================================================
void rainbow(byte startPosition) {
  int rainbowScale = 192 / LED_CNT; 	// 指定彩虹的刻度
  for (int i=0; i<LED_CNT; i++) {		// 設定每個LED的顏色
    // 0-191總共192個顏色(紅=>橙=>黃=>綠=>…=>紫)
    leds.setPixelColor(i, rainbowOrder((rainbowScale * (i + startPosition)) % 192));
  }
  leds.show();							// 開啟LED
}
// 產生彩虹色帶函數======================================================
// 輸入0~191以取得顏色值
// 顏色變化為紅=>黃=>綠=>淺綠=>藍=>粉紅=>紅...
uint32_t rainbowOrder(byte position) {
  // 6個顏色區域(每區32點)
  if (position < 31) {  // 紅=>黃 (Red = FF, blue = 0, Green = 00=>FF)
      return leds.Color(0xFF, position * 8, 0); // 只遞增綠色成份
  }
  else if (position < 63) { //黃=>綠 (Red = FF=>00, Green = FF, blue = 0)
    position -= 31;		// 第2區
    return leds.Color(0xFF - position * 8, 0xFF, 0); // 只遞減紅色成份
  }
  else if (position < 95) { //綠=>淺綠 (Red = 0, Green = FF, Blue = 00=>FF)
    position -= 63; 	// 第3區
    return leds.Color(0, 0xFF, position * 8); // 只遞增藍色成份
  }
  else if (position < 127) { //淺綠>藍 (Red = 0, Green = FF=>00, Blue = FF)
    position -= 95; 	// 第4區
    return leds.Color(0, 0xFF - position * 8, 0xFF); // 只遞減綠色成份
  }
  else if (position < 159) { //藍=>粉紅 (Red = 00=>FF, Green = 0, Blue = FF)
    position -= 127;	// 第5區
    return leds.Color(position * 8, 0, 0xFF); // 只遞增紅色成份
  }
  else  {//160 <position< 191 粉紅=>紅 (Red = FF, Green = 0, Blue = FF=>00)
    position -= 159;	// 第6區
    return leds.Color(0xFF, 0x00, 0xFF - position * 8); // 只遞減藍色成份
  }
}
